@echo off
title CLEANPROMPTER AI STUDIO PRO (v2.0 PWA)
echo Menjalankan CLEANPROMPTER AI STUDIO PRO (v2.0 PWA)...
where node >nul 2>nul
if %errorlevel%==0 (
  start http://localhost:8084
  node server.js
) else (
  echo Membuka aplikasi langsung di Browser...
  start index.html
)
