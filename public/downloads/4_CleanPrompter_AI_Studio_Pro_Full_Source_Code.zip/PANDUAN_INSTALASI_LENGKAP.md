# CLEANPROMPTER AI STUDIO PRO (v2.0 PWA)
**Official Full Source Code Package — ASWADI.DEV STORE**

Terima kasih telah membeli produk resmi di **aswadi.dev**! Paket ini berisi **100% Full Source Code** yang bebas Anda gunakan untuk usaha sendiri maupun di-custom (White-Label) untuk klien Anda tanpa biaya bulanan.

---

## CARA MENJALANKAN APLIKASI (SANGAT MUDAH)

### Cara 1: Langsung Klik 2x (Tanpa Install Apapun)
1. Ekstrak file `.zip` ini ke folder di Laptop / PC Anda.
2. Klik 2x file **`JALANKAN_APLIKASI.bat`** atau klik 2x file **`index.html`**.
3. Aplikasi langsung terbuka di browser (Chrome / Edge) dan siap digunakan 100% secara Offline maupun Online!

### Cara 2: Menjalankan via Local Server Node.js (Multi-Kasir / LAN)
1. Buka terminal / CMD di folder ini.
2. Jalankan perintah:
   ```bash
   node server.js
   ```
3. Buka `http://localhost:8084` di browser atau akses dari HP/Tablet satu jaringan WiFi.

### Cara 3: Upload ke Hosting cPanel / VPS Sendiri
1. Upload file `index.html` ke folder `public_html` di cPanel Anda, atau jalankan `server.js` menggunakan PM2 di VPS.

---

## BUTUH BANTUAN INSTALASI ATAU CUSTOM FITUR?
Silakan hubungi kami langsung melalui **Chat Shopee (aswadi.dev)** — tim kami siap membantu Anda sampai aplikasi berjalan lancar!
