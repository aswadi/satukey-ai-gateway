const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 8084;
const DB_FILE = path.join(__dirname, 'database.json');

if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify({createdAt: new Date().toISOString(), records: []}, null, 2));
}

const server = http.createServer((req, res) => {
  if (req.url === '/api/db' && req.method === 'GET') {
    res.writeHead(200, {'Content-Type': 'application/json'});
    return res.end(fs.readFileSync(DB_FILE, 'utf8'));
  }
  if (req.url === '/api/db' && req.method === 'POST') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      fs.writeFileSync(DB_FILE, body);
      res.writeHead(200, {'Content-Type': 'application/json'});
      res.end(JSON.stringify({ok: true}));
    });
    return;
  }
  const html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
  res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'});
  res.end(html);
});

server.listen(PORT, () => {
  console.log('====================================================');
  console.log('  CLEANPROMPTER AI STUDIO PRO (v2.0 PWA)');
  console.log('  Server Aktif di: http://localhost:' + PORT);
  console.log('====================================================');
});
