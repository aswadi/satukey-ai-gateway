@echo off
title SISTEM INFORMASI KLINIK (RME ICD-10) & APOTEK DIGITAL
echo Menjalankan SISTEM INFORMASI KLINIK (RME ICD-10) & APOTEK DIGITAL...
where node >nul 2>nul
if %errorlevel%==0 (
  start http://localhost:8082
  node server.js
) else (
  echo Membuka aplikasi langsung di Browser...
  start index.html
)
