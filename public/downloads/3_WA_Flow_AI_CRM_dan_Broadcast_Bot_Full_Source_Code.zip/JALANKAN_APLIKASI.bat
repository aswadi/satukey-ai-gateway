@echo off
title WA-FLOW AI CRM, AUTO-REPLY BOT & BROADCAST MARKETING (v2.4)
echo Menjalankan WA-FLOW AI CRM, AUTO-REPLY BOT & BROADCAST MARKETING (v2.4)...
where node >nul 2>nul
if %errorlevel%==0 (
  start http://localhost:8083
  node server.js
) else (
  echo Membuka aplikasi langsung di Browser...
  start index.html
)
