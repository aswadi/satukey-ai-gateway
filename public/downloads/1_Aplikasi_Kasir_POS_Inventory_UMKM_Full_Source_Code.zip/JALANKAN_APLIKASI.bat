@echo off
title APLIKASI KASIR POS & INVENTORY UMKM PRO (v3.2)
echo Menjalankan APLIKASI KASIR POS & INVENTORY UMKM PRO (v3.2)...
where node >nul 2>nul
if %errorlevel%==0 (
  start http://localhost:8081
  node server.js
) else (
  echo Membuka aplikasi langsung di Browser...
  start index.html
)
